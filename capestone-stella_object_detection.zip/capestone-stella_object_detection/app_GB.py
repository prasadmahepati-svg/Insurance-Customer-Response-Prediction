# app.py - Streamlit app for Star / Galaxy / QSO prediction
# Suitable for Gradient Boosting (uses feature_importances_)

import streamlit as st
import pandas as pd
import numpy as np
from joblib import load
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import os
import traceback

st.set_page_config(
    page_title="Star / Galaxy / QSO Predictor",
    layout="wide",
    initial_sidebar_state="auto"
)

# ---------------- CONFIG ----------------
MODEL_PATH = "Gradient_boosting.joblib"              # gradient boosting model or pipeline
LABEL_ENCODER_PATH = "label_encoder.joblib" # optional LabelEncoder for decoding targets

# FULL FEATURE SET YOU MENTIONED
FEATURE_NAMES = [
    "alpha",
    "delta",
    "u",
    "g",
    "r",
    "i",
    "z",
    "cam_col",
    "redshift",
    "plate",
    "MJD"
]
# ----------------------------------------


@st.cache_resource
def load_model(path):
    return load(path)


@st.cache_resource
def load_label_encoder(path):
    if path is None or not os.path.exists(path):
        return None
    try:
        return load(path)
    except Exception:
        return None


# Helper: convert columns to numeric where possible
def to_numeric_df(df):
    df = df.copy()
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


# Label decode utility (uses only the loaded label_encoder)
def decode_labels(preds, label_encoder):
    """
    Convert numeric predictions (or string predictions) to human-readable labels using the saved LabelEncoder.
    If label_encoder is not loaded, returns string versions of the labels.
    """
    if preds is None:
        return []
    if not isinstance(preds, (list, tuple, np.ndarray)):
        preds = [preds]

    # If already strings, return as-is
    if len(preds) > 0 and isinstance(preds[0], str):
        return list(preds)

    try:
        if label_encoder is not None:
            return list(label_encoder.inverse_transform(np.array(preds)))
    except Exception:
        pass

    return [str(p) for p in preds]


# ---------------- Load resources ----------------
model = None
try:
    model = load_model(MODEL_PATH)
except Exception as e:
    st.sidebar.error(f"Failed to load model at {MODEL_PATH}: {e}")
    st.sidebar.text(traceback.format_exc())
    model = None

label_encoder = None
try:
    label_encoder = load_label_encoder(LABEL_ENCODER_PATH)
    if label_encoder is not None:
        st.sidebar.success("LabelEncoder loaded")
        try:
            st.sidebar.write("Classes:", list(label_encoder.classes_))
        except Exception:
            pass
    else:
        st.sidebar.info("No LabelEncoder file found. Predictions will show raw labels.")
except Exception as e:
    st.sidebar.error(f"Failed to load LabelEncoder: {e}")
    st.sidebar.text(traceback.format_exc())
    label_encoder = None

# ---------------- UI MAIN ----------------
st.title("⭐ Star / Galaxy / QSO Predictor (Gradient Boosting)")
st.markdown(
    "This app predicts the class of a stellar object using the features:\n\n"
    f"**{', '.join(FEATURE_NAMES)}**.\n\n"
    "You can either enter a single sample or upload a CSV file containing these columns."
)

tab1, tab2 = st.tabs(["Single sample", "Batch (CSV)"])

# ========== TAB 1: SINGLE SAMPLE ==========
with tab1:
    st.header("Predict single sample")
    st.write("Enter feature values:")

    cols = st.columns(3)
    inputs = {}
    for i, f in enumerate(FEATURE_NAMES):
        col = cols[i % 3]
        # all are text inputs, then converted to numeric
        val = col.text_input(label=f, value="", key=f"single_{f}")
        inputs[f] = val

    if st.button("Predict single sample"):
        if model is None:
            st.error("Model not loaded. Check MODEL_PATH and try again.")
        else:
            sample = pd.DataFrame([inputs])
            sample = to_numeric_df(sample)

            if sample[FEATURE_NAMES].isnull().any(axis=None):
                st.info(
                    "Some inputs are missing or invalid and became NaN. "
                    "If the model cannot handle NaNs, prediction may fail."
                )

            X = sample[FEATURE_NAMES].copy()

            try:
                preds = model.predict(X)
                decoded = decode_labels(preds, label_encoder)
                pred_label = decoded[0] if decoded else str(preds[0])
                st.success(f"Prediction: **{pred_label}**")

                # Probabilities (if model supports predict_proba)
                if hasattr(model, "predict_proba"):
                    probs = model.predict_proba(X)[0]

                    # Try to get human-readable class names
                    try:
                        if hasattr(model, "classes_") and model.classes_ is not None:
                            class_names = decode_labels(model.classes_, label_encoder)
                        else:
                            class_names = None
                    except Exception:
                        class_names = None

                    if class_names is None:
                        class_names = [f"class_{i}" for i in range(len(probs))]

                    prob_series = pd.Series(probs, index=class_names)
                    st.write("Prediction probabilities:")
                    st.dataframe(prob_series.to_frame("probability"))
                    st.bar_chart(prob_series)

            except Exception as ex:
                st.error(f"Prediction failed: {ex}")
                st.text(traceback.format_exc())

# ========== TAB 2: BATCH (CSV) ==========
with tab2:
    st.header("Batch prediction from CSV")
    st.write(
        "Upload a CSV file that contains all of these columns:\n"
        f"**{', '.join(FEATURE_NAMES)}**"
    )
    uploaded = st.file_uploader(
        "Upload CSV file",
        type=["csv"]
    )

    if uploaded is not None:
        try:
            df = pd.read_csv(uploaded)
            st.write("Preview (first 5 rows):")
            st.dataframe(df.head())

            missing = [c for c in FEATURE_NAMES if c not in df.columns]
            if missing:
                st.error(f"Uploaded file is missing columns: {missing}")
            else:
                if st.button("Run batch prediction"):
                    X = df[FEATURE_NAMES].copy()
                    X = to_numeric_df(X)

                    try:
                        preds = model.predict(X)
                    except Exception as ex:
                        st.error(f"Prediction failed: {ex}")
                        st.text(traceback.format_exc())
                        preds = None

                    if preds is not None:
                        decoded_preds = decode_labels(preds, label_encoder)
                        df_out = df.copy()
                        df_out["prediction"] = decoded_preds

                        # Add probabilities if available
                        if hasattr(model, "predict_proba"):
                            probs = model.predict_proba(X)
                            try:
                                if hasattr(model, "classes_") and model.classes_ is not None:
                                    prob_cols = decode_labels(model.classes_, label_encoder)
                                else:
                                    prob_cols = None
                            except Exception:
                                prob_cols = None

                            if prob_cols is None:
                                prob_cols = [f"prob_{i}" for i in range(probs.shape[1])]

                            probs_df = pd.DataFrame(probs, columns=prob_cols)
                            df_out = pd.concat(
                                [df_out.reset_index(drop=True), probs_df.reset_index(drop=True)],
                                axis=1
                            )

                        st.write("Results preview:")
                        st.dataframe(df_out.head())
                        csv = df_out.to_csv(index=False).encode()
                        st.download_button(
                            "Download predictions CSV",
                            csv,
                            "predictions.csv",
                            "text/csv"
                        )
        except Exception as ex:
            st.error(f"Failed to read uploaded file: {ex}")
            st.text(traceback.format_exc())

# ========== FEATURE IMPORTANCE (Gradient Boosting) ==========
st.markdown("---")
st.header("Feature Importance (Gradient Boosting)")

if model is not None:
    # If model is a Pipeline, get the final estimator
    final_model = model
    if hasattr(model, "named_steps"):
        try:
            final_model = list(model.named_steps.values())[-1]
        except Exception:
            final_model = model

    if hasattr(final_model, "feature_importances_"):
        try:
            importances = np.array(final_model.feature_importances_)
            if importances.shape[0] == len(FEATURE_NAMES):
                fi_df = pd.DataFrame({
                    "feature": FEATURE_NAMES,
                    "importance": importances
                }).sort_values("importance", ascending=False)

                st.subheader("Feature importance (higher means more important):")
                st.table(fi_df)

                fig, ax = plt.subplots(figsize=(6, max(3, len(FEATURE_NAMES) * 0.4)))
                ax.barh(fi_df["feature"][::-1], fi_df["importance"][::-1])
                ax.set_xlabel("Feature importance")
                ax.set_ylabel("Feature")
                st.pyplot(fig)
            else:
                st.info(
                    "Feature importance length does not match FEATURE_NAMES. "
                    "Check that the model was trained with the same features."
                )
        except Exception as e:
            st.info(f"Could not compute feature importance: {e}")
    else:
        st.info("Current model does not expose feature_importances_.")
else:
    st.info("Model not loaded; cannot show feature importance.")
